import SwiftUI

@main
struct TinyLLMApp: App {
    
    @StateObject private var manager = LLMManager()
    @State private var metricsTimerStarted = false

    var body: some Scene {
        WindowGroup {
            AppSidebar()
                .environmentObject(manager)
                .frame(minWidth: 950, minHeight: 650)
                .onAppear {
                    if !metricsTimerStarted {
                        metricsTimerStarted = true
                        startMetricsTimer()
                    }
                Task {
                    await MainActor.run {
                        manager.updateMetrics()
                        manager.refreshThermalState()
                    }
                }
                }
        }
        .windowStyle(.automatic)
        .windowToolbarStyle(.unifiedCompact)

        MenuBarExtra("TinyLLM", systemImage: "brain.head.profile") {
            Section("Server Control") {
                Button("Start Server") { manager.startServer() }
                    .disabled(manager.isRunning)

                Button("Stop Server") { manager.stopServer() }
                    .disabled(!manager.isRunning)
            }

            Divider()

            Button("Show Main Window") {
                NSApplication.shared.activate(ignoringOtherApps: true)
                for window in NSApplication.shared.windows {
                    if window.title.contains("TinyLLM") {
                        window.makeKeyAndOrderFront(nil)
                    }
                }
            }

            Divider()

            Section("Model") {
                Picker("Model", selection: $manager.selectedModel) {
                    ForEach(manager.availableModels) { model in
                        Text(model.filename).tag(Optional(model))
                    }
                }
                .labelsHidden()
            }

            Divider()

            Section("Status") {
                Text("Health: \(manager.healthState.rawValue.capitalized)")
                Text("CPU: \(manager.cpuPercent)")
                Text("Memory: \(manager.memPercent)")
            }

            Divider()

            Button("Quit TinyLLM") {
                NSApplication.shared.terminate(nil)
            }
        }
        .menuBarExtraStyle(.window)

        SettingsWindow(manager: manager)
    }
}

extension TinyLLMApp {
    private func startMetricsTimer() {
        Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { _ in
            Task {
                await MainActor.run {
                    manager.updateMetrics()
                    manager.refreshThermalState()
                }
            }
        }
    }
}
