import SwiftUI

enum SidebarSection: String, CaseIterable, Identifiable {
    case home = "Home"
    case models = "Models"
    case advanced = "Advanced"
    case logs = "Logs"

    var id: String { rawValue }

    var iconName: String {
        switch self {
        case .home: return "house"
        case .models: return "square.stack.3d.down.forward"
        case .advanced: return "slider.horizontal.3"
        case .logs: return "scroll"
        }
    }
}

struct AppSidebar: View {
    @EnvironmentObject var manager: LLMManager
    @State private var selection: SidebarSection? = .home
    @State private var showDiagnostics = false

    var body: some View {
        NavigationSplitView {
            List(SidebarSection.allCases, selection: $selection) { section in
                Label(section.rawValue, systemImage: section.iconName)
                    .padding(.vertical, 2)
                    .tag(section)
            }
            .listStyle(.sidebar)
            .frame(minWidth: 200)
        } detail: {
            ZStack(alignment: .topTrailing) {
                Group {
                    switch selection ?? .home {
                    case .home:
                        MainWindowView()
                    case .models:
                        ModelManagerView()
                    case .advanced:
                        AdvancedSettingsView()
                    case .logs:
                        LogsPaneView()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                        DiagnosticsOverlay(isVisible: $showDiagnostics)
                    .padding()
            }
            .toolbar {
                ToolbarItem(placement: .automatic) {
                    Button {
                        withAnimation { showDiagnostics.toggle() }
                    } label: {
                        Label("Diagnostics", systemImage: "waveform.path.ecg")
                    }
                }
            }
        }
    }
}

struct AppSidebar_Previews: PreviewProvider {
    static var previews: some View {
        AppSidebar()
            .environmentObject(LLMManager())
    }
}
