import SwiftUI

struct AdvancedSettingsView: View {
    
    @EnvironmentObject var manager: LLMManager
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            
            header
            
            Divider()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    
                    contextSection
                    gpuSection
                    kvCacheSection
                    ropeScalingSection
                    extraArgsSection
                    recommendedSection
                }
                .padding(.vertical, 10)
            }
            
            HStack {
                Spacer()
                Button("Close") {
                    NSApplication.shared.keyWindow?.close()
                }
            }
        }
        .padding()
        .frame(width: 500, height: 650)
    }
}

// MARK: - Header

private extension AdvancedSettingsView {
    var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Advanced Settings")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text("Fine-tune llama.cpp runtime behaviour. These settings are applied the next time the server starts.")
                .font(.caption)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

// MARK: - Context / Batch / Threads

private extension AdvancedSettingsView {
    var contextSection: some View {
        GroupBox(label: Text("Context & Performance")) {
            VStack(alignment: .leading, spacing: 12) {
                
                Toggle("Manual Context Override", isOn: $manager.manualContextOverride)
                    .font(.subheadline)
                
                HStack {
                    Text("Context Size")
                    Spacer()
                    Text("\(manager.ctxSize)")
                }
                Slider(value: Binding(
                    get: { Double(manager.ctxSize) },
                    set: { manager.ctxSize = Int($0) }
                ), in: 1024...65536, step: 1024)
                
                HStack {
                    Text("Batch Size")
                    Spacer()
                    Text("\(manager.batchSize)")
                }
                Slider(value: Binding(
                    get: { Double(manager.batchSize) },
                    set: { manager.batchSize = Int($0) }
                ), in: 64...2048, step: 64)
                
                HStack {
                    Text("Threads")
                    Spacer()
                    Text("\(manager.threadCount)")
                }
                Slider(value: Binding(
                    get: { Double(manager.threadCount) },
                    set: { manager.threadCount = Int($0) }
                ), in: 1...Double(manager.maxThreadCount), step: 1)
                
                if let warning = manager.contextWarning {
                    Text("⚠️ \(warning)")
                        .font(.caption)
                        .foregroundColor(.orange)
                        .padding(.top, 4)
                }
            }
            .padding(.top, 4)
        }
    }
}

// MARK: - GPU Settings

private extension AdvancedSettingsView {
    var gpuSection: some View {
        GroupBox(label: Text("GPU Acceleration")) {
            VStack(alignment: .leading, spacing: 12) {
                
                HStack {
                    Text("GPU Layers")
                    Spacer()
                    Text("\(manager.nGpuLayers)")
                }
                Slider(value: Binding(
                    get: { Double(manager.nGpuLayers) },
                    set: { manager.nGpuLayers = Int($0) }
                ), in: 0...200, step: 1)
                
                Toggle("Flash Attention (Metal-optimized)", isOn: $manager.enableFlashAttention)
                
            }
            .padding(.top, 4)
        }
    }
}

// MARK: - KV Cache Types

private extension AdvancedSettingsView {
    var kvCacheSection: some View {
        GroupBox(label: Text("KV Cache Quantization")) {
            VStack(alignment: .leading, spacing: 12) {
                
                Picker("K Cache", selection: $manager.cacheTypeK) {
                    Text("q4_0").tag("q4_0")
                    Text("q4_1").tag("q4_1")
                    Text("q5_0").tag("q5_0")
                    Text("q5_1").tag("q5_1")
                }
                
                Picker("V Cache", selection: $manager.cacheTypeV) {
                    Text("q4_0").tag("q4_0")
                    Text("q4_1").tag("q4_1")
                    Text("q5_0").tag("q5_0")
                    Text("q5_1").tag("q5_1")
                }
                
                Toggle("Auto-adjust KV Cache (Host may override)", isOn: $manager.enableAutoKV)
                
            }
            .padding(.top, 4)
        }
    }
}

// MARK: - Rope Scaling

private extension AdvancedSettingsView {
    var ropeScalingSection: some View {
        GroupBox(label: Text("RoPE Scaling")) {
            VStack(alignment: .leading, spacing: 12) {
                
                Toggle("Enable RoPE Scaling", isOn: $manager.enableRopeScaling)
                
                if manager.enableRopeScaling {
                    HStack {
                        Text("Scale")
                        Spacer()
                        Text(String(format: "%.1f", manager.ropeScalingValue))
                    }
                    Slider(value: $manager.ropeScalingValue, in: 0.5...4.0, step: 0.1)
                }
                
                Text("RoPE scaling helps preserve attention range at high context sizes.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.top, 2)
            }
            .padding(.top, 4)
        }
    }
}

// MARK: - Extra Args

private extension AdvancedSettingsView {
    var extraArgsSection: some View {
        GroupBox(label: Text("Raw Extra Arguments")) {
            VStack(alignment: .leading, spacing: 10) {
                TextEditor(text: $manager.extraArgsRaw)
                    .font(.system(.caption, design: .monospaced))
                    .frame(minHeight: 80)
                    .border(Color.gray.opacity(0.3), width: 1)
                
                Text("These are appended as-is to llama-server’s launch arguments.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
}

// MARK: - Recommended Settings

private extension AdvancedSettingsView {
    var recommendedSection: some View {
        GroupBox(label: Text("Recommended Tuning")) {
            VStack(alignment: .leading, spacing: 10) {
                
                Toggle("Auto-apply Recommended Settings", isOn: $manager.autoApplyRecommended)
                
                Text(manager.recommendedSummary)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 4)
                
                Button("Apply Recommended Now") {
                    manager.applyRecommendedSettings()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
}
